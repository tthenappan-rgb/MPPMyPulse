package com.pral.mppmypulse;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.provider.DocumentsContract;
import java.io.OutputStream;
import java.io.IOException;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int CREATE_PDF_REQUEST = 4817;
    private WebView webView;
    private byte[] pendingPdfBytes;
    private String pendingPdfName = "MPP-Progress.pdf";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
            private boolean handleUrl(Uri uri) {
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                // Keep local assets and the PDF library's HTTPS requests in WebView.
                if (scheme.equals("file") || scheme.equals("about") || scheme.equals("https") && !host.equals("wa.me") || scheme.equals("http") && !host.equals("wa.me")) return false;
                if (scheme.equals("https") && host.equals("wa.me")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "Unable to open WhatsApp link", Toast.LENGTH_LONG).show(); }
                    return true;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "No app found to open this link", Toast.LENGTH_SHORT).show(); }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("MPP report", text == null ? "" : text));
                Toast.makeText(MainActivity.this, "MPP report copied", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void savePdf(String dataUri, String filename) {
            try {
                int comma = dataUri == null ? -1 : dataUri.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Invalid PDF data");
                byte[] bytes = Base64.decode(dataUri.substring(comma + 1), Base64.DEFAULT);
                if (bytes.length == 0) throw new IllegalArgumentException("PDF is empty");
                String safeName = (filename == null ? "MPP-Progress.pdf" : filename).replaceAll("[\\\\/:*?\"<>|]", "_");
                if (!safeName.toLowerCase().endsWith(".pdf")) safeName += ".pdf";
                pendingPdfBytes = bytes;
                pendingPdfName = safeName;
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/pdf");
                    intent.putExtra(Intent.EXTRA_TITLE, pendingPdfName);
                    startActivityForResult(intent, CREATE_PDF_REQUEST);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not prepare PDF. Please try again.", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_PDF_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingPdfBytes = null;
            Toast.makeText(this, "PDF save cancelled", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri destination = data.getData();
        byte[] bytes = pendingPdfBytes;
        pendingPdfBytes = null;
        if (bytes == null) { Toast.makeText(this, "PDF data is no longer available. Please generate it again.", Toast.LENGTH_LONG).show(); return; }
        try (OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
            if (out == null) throw new IOException("Could not open selected file");
            out.write(bytes);
            out.flush();
            Toast.makeText(this, "PDF saved successfully", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "PDF could not be saved. Please try another folder.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
